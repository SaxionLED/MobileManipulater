#!/usr/bin/env python
import sys
import rospy
from drrobot_jaguar4x4_player.msg import MotorInfoArray
from geometry_msgs.msg import Vector3


class EncoderData:
    def __init__(self, pub):
        self.jaguarEncoderSub = rospy.Subscriber("/drrobot_motor",MotorInfoArray,self.encoderCallback)
	self.encoder_pub = pub
	#self.validEncoders = ["drrobot_motor_0","drrobot_motor_1","drrobot_motor_3","drrobot_motor_4"]
	self.validEncoders = ["drrobot_motor_3","drrobot_motor_4"]


    def encoderCallback(self, data):
	d = []
	for motor in data.motorInfos:
	    if motor.header.frame_id in self.validEncoders:
		d.append(motor.encoder_pos)

	v = Vector3()	
	v.x = d[0]
	v.y = d[1]
	v.z = 0
	self.encoder_pub.publish(v)	

	
def main(arg):
    encoder_pub = rospy.Publisher("wheel_encoder", Vector3, queue_size=10)
    rospy.init_node('Encoder_transformer', anonymous=True)    
    rate = rospy.Rate(1) #in Hz

    encoder =  EncoderData(encoder_pub)    

    while not rospy.is_shutdown():
        rate.sleep()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down"


if __name__ == '__main__':
    main(sys.argv)





